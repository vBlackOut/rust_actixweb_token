// src/auth.rs
use chrono::{Local, NaiveDateTime};
use std::collections::HashMap;
use actix_web::HttpResponse;
use crate::utils::{load_tokens, update_expired_dates}; // Importer des fonctions d'autres modules
use serde::{Deserialize, Serialize};

impl AuthData {
    pub fn into_auth_json(self) -> AuthJson {
        match self {
            AuthData::Single(auth_json) => auth_json,
        }
    }
}

#[derive(Serialize, Deserialize, Debug)]
pub struct AuthJson {
    pub username: String,
    pub password: String,
    pub expire: String,
}

pub fn find_expired_tokens(
    username: &str,
    password: &str,
    tokens: &HashMap<String, AuthData>,
) -> Result<Vec<String>, String> {
    let mut expired_tokens = Vec::new();

    for (token_key, auth_data) in tokens {
        match auth_data {
            AuthData::Single(credential) => {
                if credential.username == username && credential.password == password {
                    let is_expired = if let Ok(expire_date) = NaiveDateTime::parse_from_str(
                        &credential.expire,
                        "%d-%m-%Y %H:%M:%S",
                    ) {
                        Local::now().naive_local() > expire_date
                    } else {
                        true
                    };

                    if is_expired {
                        expired_tokens.push(token_key.clone());
                    } else {
                        return Err("Token is expired".to_string());
                    }
                }
            }
        }
    }

    if expired_tokens.is_empty() {
        Err("Invalid credentials".to_string())
    } else {
        Ok(expired_tokens)
    }
}

pub fn update_expired_dates(tokens: &HashMap<String, AuthData>) {
    let tokens_json: HashMap<String, AuthJson> = tokens
        .iter()
        .map(|(key, value)| (key.clone(), value.clone().into_auth_json()))
        .collect();

    let serialized = serde_json::to_string_pretty(&tokens_json).expect("Failed to serialize tokens");
    let mut file = OpenOptions::new()
        .write(true)
        .truncate(true)
        .open("config_auth.json")
        .expect("Failed to open file for writing");

    file.write_all(serialized.as_bytes())
        .expect("Failed to write to file");
}
