mod auth; // Charger le module auth.rs
mod utils; // Charger le module utils.rs

use actix_web::{web, App, HttpResponse, HttpServer}; // Importer les types nécessaires
use auth::{find_expired_tokens, update_expired_tokens}; // Importer les fonctions du module auth
use utils::{load_tokens}; // Importer les fonctions utilitaires
use crate::auth::check_credential;

fn check_credential(username: String, password: String) -> HttpResponse {
    let mut tokens = load_tokens();

    let expired_tokens = match find_expired_tokens(&username, &password, &tokens) {
        Ok(tokens) => tokens,
        Err(err) => return HttpResponse::Unauthorized().body(err),
    };

    update_expired_tokens(&mut tokens, expired_tokens)
}

async fn login(form: web::Form<utils::AuthJson>) -> impl Responder {
    let response = check_credential(form.username.clone(), form.password.clone());
    response
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    HttpServer::new(|| {
        App::new()
            .route("/login", web::post().to(login))
    })
    .bind(("127.0.0.1", 8080))?
    .run()
    .await
}
