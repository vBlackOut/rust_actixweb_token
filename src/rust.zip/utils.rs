// src/utils.rs
use std::collections::HashMap;
use std::fs::{File, OpenOptions};
use std::io::{Read, Write};
use serde::Deserialize;
use crate::auth::AuthData; // Importer AuthData depuis auth.rs
use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Debug)]
pub struct AuthJson {
    pub username: String,
    pub password: String,
    pub expire: String,
}

pub fn load_tokens() -> HashMap<String, AuthData> {
    let mut contents = String::new();
    let mut file = File::open("config_auth.json").expect("Failed to open file");
    file.read_to_string(&mut contents).expect("Failed to read file");

    serde_json::from_str(&contents).expect("Invalid JSON format")
}

pub fn update_expired_dates(tokens: &HashMap<String, AuthJson>) {
    let serialized = serde_json::to_string_pretty(tokens).expect("Failed to serialize tokens");
    let mut file = OpenOptions::new()
        .write(true)
        .truncate(true)
        .open("config_auth.json")
        .expect("Failed to open file for writing");

    file.write_all(serialized.as_bytes())
        .expect("Failed to write to file");
}
